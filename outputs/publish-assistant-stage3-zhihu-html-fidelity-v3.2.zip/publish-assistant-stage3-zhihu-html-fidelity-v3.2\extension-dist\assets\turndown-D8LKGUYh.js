import{T as q,d as v}from"./jszip.min-BVx0r_9g.js";const C={debug:0,info:1,warn:2,error:3},O=typeof import.meta<"u"&&!0||typeof process<"u"&&!0;let D={level:O?"warn":"debug"};function j(n){const e=r=>C[r]>=C[D.level];return{debug:(...r)=>{e("debug")&&console.log(`[${n}]`,...r)},info:(...r)=>{e("info")&&console.log(`[${n}]`,...r)},warn:(...r)=>{e("warn")&&console.warn(`[${n}]`,...r)},error:(...r)=>{e("error")&&console.error(`[${n}]`,...r)}}}const m=j("Turndown"),E=["zhida.zhihu.com"],L=[{domain:"link.zhihu.com",param:"target"}];function H(n){let e=n;for(let t=0;t<3;t++){const a=e;if(e=e.replace(/&amp;/g,"&"),a===e)break}e=e.replace(/&#[xX]([0-9a-fA-F]+);/g,(t,a)=>String.fromCharCode(parseInt(a,16))),e=e.replace(/&#(\d+);/g,(t,a)=>String.fromCharCode(parseInt(a,10)));const r={"&lt;":"<","&gt;":">","&amp;":"&","&quot;":'"',"&apos;":"'","&#039;":"'","&nbsp;":" ","&ndash;":"–","&mdash;":"—","&lsquo;":"‘","&rsquo;":"’","&ldquo;":"“","&rdquo;":"”","&copy;":"©","&reg;":"®","&trade;":"™","&hellip;":"…"};for(const[t,a]of Object.entries(r))e=e.split(t).join(a);return e}const B=["span","em","strong","b","i","u","s","strike","del","ins","mark","sub","sup","small","big","font","a","code","pre","kbd","samp","var","tt","div","p","section","article","header","footer","aside","nav","main","figure","figcaption","blockquote","address","ul","ol","li","dl","dt","dd","table","thead","tbody","tfoot","tr","th","td","caption","colgroup","col","br","hr","wbr","abbr","acronym","cite","dfn","q","time","ruby","rt","rp","bdi","bdo","data","meter","progress","output","details","summary","mpvoice","mpprofile","qqmusic","mpcps"];function I(n){const e="\0__CODE_LT__\0",r="\0__CODE_GT__\0";let t=n;t=t.replace(/&lt;/gi,e),t=t.replace(/&gt;/gi,r),t=t.replace(/&#0*60;/gi,e),t=t.replace(/&#0*62;/gi,r),t=t.replace(/&#x0*3[cC];/gi,e),t=t.replace(/&#x0*3[eE];/gi,r);const a=B.join("|");return t=t.replace(new RegExp(`<(${a})\\b[^>]*\\/?>`,"gi"),""),t=t.replace(new RegExp(`<\\/(${a})>`,"gi"),""),t=t.replace(new RegExp(e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),"g"),"<"),t=t.replace(new RegExp(r.replace(/[.*+?^${}()|[\]\\]/g,"\\$&"),"g"),">"),t=H(t),t}function z(n){let e=n.replace(/<br\s*\/?>/gi,`
`).replace(/<\/div>/gi,`
`).replace(/<\/p>/gi,`
`).replace(/<\/li>/gi,`
`).replace(/<\/?code[^>]*>/gi,"");return e=I(e),e.trim()}function P(n){let e=n.replace(/^\s+|\s+$/g,"");return e=e.replace(/\|/g,"\\|"),e=e.replace(/\s*\r?\n\s*/g,"<br>"),e=e.replace(/[ \t]{2,}/g," "),e}function R(n,e){const r=P(n),t=e.parentNode;if(!t)return"| "+r+" |";const a=t.querySelectorAll("th, td");return(Array.from(a).indexOf(e)===0?"| ":" ")+r+" |"}function k(n){return n.querySelector("tr")}function y(n){const e=n.parentNode;if(!e)return!1;const r=n.querySelectorAll("th, td");return e.nodeName==="THEAD"||e.firstChild===n&&(e.nodeName==="TABLE"||F(e))&&r.length>0&&Array.from(r).every(t=>t.nodeName==="TH")}function F(n){const e=n.previousSibling;return n.nodeName==="TBODY"&&(!e||e.nodeName==="THEAD"&&/^\s*$/i.test(e.textContent||""))}function G(n){n.addRule("figure",{filter:"figure",replacement:function(e){return e}}),n.addRule("figcaption",{filter:"figcaption",replacement:function(e){return e?`
*`+e.trim()+`*
`:""}}),n.addRule("tableCell",{filter:["th","td"],replacement:function(e,r){return R(e,r)}}),n.addRule("tableRow",{filter:"tr",replacement:function(e,r){const t=r;let a="";const c={left:":--",right:"--:",center:":-:"};return y(t)&&t.querySelectorAll("th, td").forEach(s=>{var o;let p="---";const g=(((o=s.getAttribute)==null?void 0:o.call(s,"align"))||"").toLowerCase();g&&c[g]&&(p=c[g]),a+=R(p,s)}),`
`+e+(a?`
`+a:"")}}),n.addRule("table",{filter:function(e){try{if(e.nodeName!=="TABLE")return!1;const t=k(e);return t?y(t):!1}catch(r){return m.error("Table filter error:",r),!1}},replacement:function(e){return e=e.replace(/\n\n/g,`
`),`

`+e+`

`}}),n.addRule("tableSection",{filter:["thead","tbody","tfoot"],replacement:function(e){return e}}),n.addRule("preCode",{filter:["pre"],replacement:function(e,r){const t=r;let a="";const c=t.getAttribute("data-lang");if(c&&(a=c),!a){const o=t.querySelector("code");if(o){const u=(o.className||"").match(/language-(\w+)/);u&&(a=u[1])}}if(!a){const l=(t.className||"").match(/language-(\w+)/);l&&(a=l[1])}a||(a="bash");const i=t.querySelectorAll("code");let s;if(i.length>1){const o=[];i.forEach(l=>{o.push(l.innerText||l.textContent||"")}),s=o.join(`
`)}else s=t.innerText||"";if(s=s.replace(/\r\n/g,`
`).replace(/\r/g,`
`).replace(/^\n+/,"").replace(/\n+$/,""),!s.trim())return"";a=a.replace(/[^a-zA-Z0-9+#._-]/g,"").toLowerCase();let p="```";const g=s.match(/`+/g);if(g){const o=Math.max(...g.map(l=>l.length));o>=3&&(p="`".repeat(o+1))}return`
`+p+a+`
`+s+`
`+p+`
`}}),n.addRule("sourcePlatformLinks",{filter:function(e){if(e.nodeName!=="A")return!1;const r=e.getAttribute("href")||"";return E.some(t=>r.includes(t))||L.some(t=>r.includes(t.domain))},replacement:function(e,r){const t=r.getAttribute("href")||"";if(E.some(c=>t.includes(c)))return e;const a=L.find(c=>t.includes(c.domain));if(a)try{const i=new URL(t).searchParams.get(a.param);if(i)return"["+e+"]("+i+")"}catch{}return"["+e+"]("+t+")"}}),n.keep(function(e){try{if(e.nodeName!=="TABLE")return!1;const t=k(e);return t?!y(t):!0}catch(r){return m.error("Table keep filter error:",r),!1}})}function V(n,e={}){return w(n)}function T(n){if(!n)return"";const e=[/language-(\w+)/i,/lang-(\w+)/i,/\bhljs\s+(\w+)/i,/\b(javascript|typescript|python|java|cpp|c|csharp|go|rust|ruby|php|swift|kotlin|scala|sql|html|css|json|xml|yaml|markdown|bash|shell|powershell)\b/i];for(const r of e){const t=n.match(r);if(t)return t[1].toLowerCase()}return""}function w(n){let e=n;return e=e.replace(/<ul[^>]*class=["'][^"']*code-snippet__line-index[^"']*["'][^>]*>[\s\S]*?<\/ul>/gi,""),e=U(e),e=e.replace(/<h1[^>]*>([\s\S]*?)<\/h1>/gi,`
# $1
`),e=e.replace(/<h2[^>]*>([\s\S]*?)<\/h2>/gi,`
## $1
`),e=e.replace(/<h3[^>]*>([\s\S]*?)<\/h3>/gi,`
### $1
`),e=e.replace(/<h4[^>]*>([\s\S]*?)<\/h4>/gi,`
#### $1
`),e=e.replace(/<h5[^>]*>([\s\S]*?)<\/h5>/gi,`
##### $1
`),e=e.replace(/<h6[^>]*>([\s\S]*?)<\/h6>/gi,`
###### $1
`),e=e.replace(/<(strong|b)[^>]*>([\s\S]*?)<\/\1>/gi,"**$2**"),e=e.replace(/<(em|i)[^>]*>([\s\S]*?)<\/\1>/gi,"*$2*"),e=e.replace(/<a[^>]*href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/gi,"[$2]($1)"),e=e.replace(/<img[^>]*src="([^"]*)"[^>]*alt="([^"]*)"[^>]*\/?>/gi,"![$2]($1)"),e=e.replace(/<img[^>]*src="([^"]*)"[^>]*\/?>/gi,"![]($1)"),e=e.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi,(r,t)=>{let a="";const c=r.match(/<pre[^>]*data-lang(?:uage)?=["'](\w+)["']/),i=r.match(/<pre[^>]*class="([^"]*)"/);c?a=c[1]:i&&(a=T(i[1]));const s=t.match(/<code[^>]*data-lang(?:uage)?=["'](\w+)["']/),p=t.match(/<code[^>]*class="([^"]*)"/);a||(s?a=s[1]:p&&(a=T(p[1])));const g=z(t);return"\n```"+a+`
`+g+"\n```\n"}),e=e.replace(/<code[^>]*>([\s\S]*?)<\/code>/gi,"`$1`"),e=e.replace(/<ul[^>]*>([\s\S]*?)<\/ul>/gi,`$1
`),e=e.replace(/<ol[^>]*>([\s\S]*?)<\/ol>/gi,`$1
`),e=e.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi,`- $1
`),e=e.replace(/<p[^>]*>([\s\S]*?)<\/p>/gi,`
$1
`),e=e.replace(/<br\s*\/?>/gi,`
`),e=e.replace(/<hr\s*\/?>/gi,`
---
`),e=e.replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi,(r,t)=>`
`+t.trim().split(`
`).map(a=>"> "+a).join(`
`)+`
`),e=e.replace(/<script[^>]*type=["']math\/tex[^"']*display[^"']*["'][^>]*>([\s\S]*?)<\/script>/gi,`
$$$$
$1
$$$$
`),e=e.replace(/<script[^>]*type=["']math\/tex["'][^>]*>([\s\S]*?)<\/script>/gi," $$$$$1$$$$ "),e=e.replace(/<\/?[^>]+(>|$)/g,""),e=e.replace(/&amp;/g,"&"),e=e.replace(/&lt;/g,"<"),e=e.replace(/&gt;/g,">"),e=e.replace(/&quot;/g,'"'),e=e.replace(/&#039;/g,"'"),e=e.replace(/&nbsp;/g," "),e=e.replace(/\n{3,}/g,`

`),e=e.trim(),e}function U(n){return n=n.replace(/<figure[^>]*>([\s\S]*?)<\/figure>/gi,(e,r)=>{if(/<table[^>]*>/i.test(r)){const t=r.match(/<table[^>]*>([\s\S]*?)<\/table>/i),a=r.match(/<figcaption[^>]*>([\s\S]*?)<\/figcaption>/i);if(t){let c=t[0];if(a){const i=a[1].replace(/<[^>]+>/g,"").trim();i&&(c+=`
*`+i+`*
`)}return c}}return e}),n.replace(/<table[^>]*>([\s\S]*?)<\/table>/gi,(e,r)=>{const t=r.match(/<thead[^>]*>([\s\S]*?)<\/thead>/i),a=[],c=[];let i=-1;const s=r.match(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)||[];for(let l=0;l<s.length;l++){const u=s[l],f=[],h=[],d=u.match(/<t[hd][^>]*>([\s\S]*?)<\/t[hd]>/gi)||[],M=d.length>0&&d.every(b=>b.startsWith("<th"));for(const b of d){const $=b.match(/<t[hd]([^>]*)>([\s\S]*?)<\/t[hd]>/i);if($){const x=$[1],A=$[2],_=x.match(/align=["']?(left|center|right)["']?/i)||x.match(/style=["'][^"']*text-align:\s*(left|center|right)/i),N=_?_[1].toLowerCase():"";h.push(N);let S=A.replace(/<br\s*\/?>/gi," ").replace(/<[^>]+>/g,"").replace(/&nbsp;/g," ").replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/\s+/g," ").trim();S=S.replace(/\|/g,"\\|"),f.push(S)}}f.length>0&&(a.push(f),c.push(h),t&&u.indexOf("<th")!==-1?i=l:l===0&&M&&(i=0))}if(a.length===0)return"";i===-1&&(i=0);const p=[],g=Math.max(...a.map(l=>l.length)),o=c[i]||[];for(let l=0;l<a.length;l++){const u=a[l];for(;u.length<g;)u.push("");if(p.push("| "+u.join(" | ")+" |"),l===i){const f=[];for(let h=0;h<g;h++){const d=o[h]||"";d==="left"?f.push(":---"):d==="center"?f.push(":---:"):d==="right"?f.push("---:"):f.push("---")}p.push("| "+f.join(" | ")+" |")}}return`

`+p.join(`
`)+`

`})}function W(n,e={}){if(typeof document>"u")return m.warn("No native DOM, falling back to regex conversion"),w(n);try{const r=new q({headingStyle:e.headingStyle||"atx",hr:e.hr||"---",bulletListMarker:e.bulletListMarker||"-",codeBlockStyle:e.codeBlockStyle||"fenced",fence:e.fence||"```",emDelimiter:e.emDelimiter||"*",strongDelimiter:e.strongDelimiter||"**",linkStyle:e.linkStyle||"inlined",linkReferenceStyle:e.linkReferenceStyle||"full"});G(r);const t=document.createElement("div");return t.innerHTML=n,t.querySelectorAll('ul.code-snippet__line-index, ul[class*="code-snippet__line-index"]').forEach(a=>a.remove()),r.turndown(t)}catch(r){return m.error("Native DOM conversion failed:",r),w(n)}}function X(n){return v.parse(n,{async:!1})}export{E as S,L as a,V as b,j as c,W as h,X as m};
