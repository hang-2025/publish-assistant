@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\VERIFY-SHA256.ps1" %*
exit /b %errorlevel%
