@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\START-HERE.ps1"
exit /b %errorlevel%
