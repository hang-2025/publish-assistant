@echo off
setlocal
cd /d "%~dp0local-service"
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js 18.17 or newer is required.
  pause
  exit /b 1
)
echo Starting Yizao local service on http://127.0.0.1:8788 ...
echo The first-run pairing token is stored only in local-service\data and is not included in this package.
node server.mjs
if errorlevel 1 pause
